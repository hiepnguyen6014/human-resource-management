#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(){
    FILE* fp = fopen(".\\testcases\\testcase1\\diem.csv", "r");
    if(fp == NULL){
        printf("Error");
    }
    char line[1000];
    while(fgets(line, 1000, fp)){
        printf("%s\n", line);
    }
    fclose(fp);
    return 0;
}